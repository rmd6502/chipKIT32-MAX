#ifndef __LIBC_THREAD_H__
#define __LIBC_THREAD_H__

#ifdef __cplusplus
extern "C" {
#endif

#warning libc_thread.h is not provided in this libc

#ifdef __cplusplus
}
#endif

#endif
