/* Generated automatically. */
static const char configuration_arguments[] = "../../cxx/src45x/gcc/configure --build=i386-pc-linux-gnu --host=i386-pc-linux-gnu --target=pic32mx --disable-threads --enable-static --disable-libmudflap --disable-libssp --disable-libstdcxx-pch --disable-hosted-libstdcxx --with-arch=pic32mx --enable-sgxx-sde-multilibs --disable-threads --with-gnu-as --with-gnu-ld --enable-languages=c,c++ --disable-shared --without-newlib --disable-nls --enable-gofast --disable-shared --disable-libgomp --without-newlib --without-headers --enable-obsolete --disable-libffi --disable-bootstrap --enable-obsolete --disable-libfortran --prefix=/home/c11067/work/C32/builds/chipKIT/install-image --libexecdir=/home/c11067/work/C32/builds/chipKIT/install-image/pic32mx/bin --program-prefix=pic32- --with-dwarf2 --with-host-libstdcxx='-static-libgcc -Wl,-Bstatic,-lstdc++,-Bdynamic -lm' --with-zlib=/home/c11067/work/C32/builds/chipKIT/cross-build/host-libs --disable-__cxa_atexit CFLAGS_FOR_BUILD=-DSKIP_LICENSE_MANAGER CFLAGS=-DSKIP_LICENSE_MANAGER 'XGCC_FLAGS_FOR_TARGET=-fno-rtti -fno-enforce-eh-specs -fno-exceptions' --enable-cxx-flags='-fno-exceptions -ffunction-sections' --disable-sjlj-exceptions";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "arch", "pic32mx" }, { "synci", "no-synci" } };
