
/*
 * errno.h : error number definitions
 */


#ifndef __ERRNO_H
#define __ERRNO_H

#include <sys/errno.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int errno;

#ifdef __cplusplus
}
#endif

#endif /* !defined __ERRNO_H */

